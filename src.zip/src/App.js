// import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
//import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Home from './com/Home';
import About from './com/About';
import Listing from './com/Listing';
import Auth from './com/Auth';
import Protected from './com/Protected';
import Nav from './com/Nav';


import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  // const [token, setToken] = useState();
  // if(!token) {
  //   return <Auth setToken={setToken} />
  // }
  return (
    <div className="App">

      <Router>
        <Nav/>
        <Switch>
          <Route path="/home">
            {/* <Home /> */}
            <Protected com={Home}/>
          </Route>
          <Route path="/about">
            {/* <About /> */}
            <Protected com={About}/>
          </Route>
          <Route path="/list">
            {/* <About /> */}
            <Protected com={Listing}/>
          </Route>
          <Route path="/">
            <Auth />
            
          </Route>
          
        </Switch>
      </Router>
    </div>
    // <div className="App">
    //   <h1>Application</h1>
    //   <BrowserRouter>
    //     <Switch>
    //       <Route path="./com/Home">
    //         <Home />
    //       </Route>
    //       <Route path="./com/About">
    //         <About />
    //       </Route>
    //       <Route path="./com/Listing">
    //         <Listing />
    //       </Route>
    //     </Switch>
    //   </BrowserRouter>
    // </div>
  );
}

export default App;
