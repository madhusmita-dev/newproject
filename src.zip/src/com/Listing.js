import React,{Component} from 'react';
class Listing extends Component{
    cars = [{'id':'73','foo':'bar'},{'id':'45','foo':'bar'}]
    constructor(){
        super()
        this.state={
            item:null
        }
    }
    componentDidMount(){
        
        this.setState({item:this.cars})
        
    }
    render(){
        return(
            <div>{
                this.state.item?
                this.state.item.map((item,i)=><div key={i}><h1 key={i}>{item.foo}</h1></div>):null
            }
               
                </div>
        )
    }
}
export default Listing