import React, { Component } from 'react';
import {
    Redirect
} from "react-router-dom";
function Protected(pros) {
    //const cmd=pros.com;
    
    var auth = JSON.parse(localStorage.getItem("profile"))
    console.warn(auth)
    return <div>{auth?<pros.com />:<Redirect to="login"></Redirect>}</div>
}
export default Protected;