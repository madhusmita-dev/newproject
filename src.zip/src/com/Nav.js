import React, { Component } from 'react';

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
class Nav extends Component {
    logout(){
        localStorage.clear()
    }
    render() {
        return (
            <div>
                <div className="link_bar">
                <Link to="home">Home</Link>
                <Link to="about">About</Link>
                <Link to="list">Product Listing</Link>
                <Link to="/">Login</Link>
                <button type="submit" onClick={() => this.logout()} >Logout</button>
                </div>
            </div>
        )
    }
}
export default Nav