import React, { Component } from 'react';
import {
    Redirect
} from "react-router-dom";
class Auth extends Component {
    state = {
        user: 'username',
        password: 'password'
    };
    constructor(){
        super()
        this.state={
            isRegister:false
        }
    }

    login() {
        console.log("ok"+JSON.stringify(this.state))
        var un = document.loginform.usr.value;
        var pw = document.loginform.pword.value;
        if ((un == this.state.usr) && (pw == this.state.pword)) {
            alert("ok")
            if (this.state != undefined || this.state != null) {
                localStorage.setItem("profile", JSON.stringify(this.state));
            }

        }
        else {
            alert("Login was unsuccessful, please check your username and password");
            return false;
        }


    }

    render() {
        var auth = JSON.parse(localStorage.getItem("profile"))
        return (
            <div>
                {
                    auth?<Redirect to="home"></Redirect>:null
                }
                {
                    !this.state.isRegister?
                    <form name="loginform" className="login_from" >
                    <label>Email</label>
                    <input type="text" name="usr" onChange={(e) => { this.setState({ usr: e.target.value }) }} placeholder="Email" /><br />
                    <label>Password</label>
                    <input type="password" name="pword" onChange={(e) => { this.setState({ pword: e.target.value }) }} placeholder="password" /><br />
                    <button type="submit" onClick={() => this.login()} >Login</button>
                    <button type="submit" value="Login" onClick={() => this.setState({ isRegister:true })}>go to Register</button>
                </form>
              :
              <form name="loginform" className="login_from" >
                  <label>User name</label>
                  <input type="text" name="name" onChange={(e) => { this.setState({name: e.target.value }) }} placeholder="Name" /><br/>
                    <label>Email</label>
                    <input type="text" name="usr" onChange={(e) => { this.setState({ usr: e.target.value }) }} placeholder="Email" /><br />
                    <label>Password</label>
                    <input type="password" name="pword" onChange={(e) => { this.setState({ pword: e.target.value }) }} placeholder="password" /><br />
                    <label>Conform Password</label>
                    <input type="password" name="conformpword" onChange={(e) => { this.setState({ conformpword: e.target.value }) }} placeholder="Conform password" /><br />
                    <button type="submit" onClick={() => this.login()} >Register</button>
                    <button type="submit" onClick={() => this.setState({ isRegister:false })} >go to Login</button>

                </form>
               
                }
                
                

            </div>
    

        )
    }
}
export default Auth